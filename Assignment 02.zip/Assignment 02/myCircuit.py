# Name: Md Tahmid Ul Islam Tonmoy | Student ID: u3310875 | Date: 16.09.2025

from itertools import product

def parse_bit(s: str) -> bool:
    s = s.strip().lower()
    if s in ("1", "t", "true", "y", "yes"): return True
    if s in ("0", "f", "false", "n", "no"): return False
    raise ValueError(f"Invalid bit: {s!r}. Use 0/1 or true/false.")

def to01(x: bool) -> int:
    return 1 if x else 0

def circuit_g(A: bool, B: bool, C: bool) -> bool:
    # X = (A and not B and A) or (A and not B and C) or (A and B and C)
    return (A and (not B) and A) or (A and (not B) and C) or (A and B and C)

def circuit_j(A: bool, B: bool, C: bool) -> bool:
    # Y = A and ((not B) or C)
    return A and ((not B) or C)

def interactive():
    try:
        A = parse_bit(input("A (0/1 or T/F): "))
        B = parse_bit(input("B (0/1 or T/F): "))
        C = parse_bit(input("C (0/1 or T/F): "))
    except ValueError as e:
        print(e); return

    X = circuit_g(A, B, C)
    Y = circuit_j(A, B, C)

    print(f"\nInputs : A={to01(A)} B={to01(B)} C={to01(C)}")
    print(f"Outputs: X={to01(X)}  Y={to01(Y)}  {'(equal)' if X==Y else '(different)'}")

def print_truth_table_and_check():
    print("A B C | X  Y   (X = (A·B̄·A)+(A·B̄·C)+(A·B·C),  Y = A·(B̄+C))")
    all_same = True
    for A, B, C in product((0,1), repeat=3):
        Ab, Bb, Cb = bool(A), bool(B), bool(C)
        X = circuit_g(Ab, Bb, Cb)
        Y = circuit_j(Ab, Bb, Cb)
        same = X == Y
        all_same &= same
        mark = "" if same else "  <-- diff"
        print(f"{A} {B} {C} | {to01(X)}  {to01(Y)}{mark}")
    print("\nEquivalent?", "YES" if all_same else "NO")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--table":
        print_truth_table_and_check()
    else:
        interactive()
