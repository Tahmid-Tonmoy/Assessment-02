# Name: Md Tahmid Ul Islam Tonmoy | Student ID: u3310875 | Date: 16.09.2025

def toggle_projector(room):
    room["projector_on"] = not room["projector_on"]
    print(f"Projector is now {'ON' if room['projector_on'] else 'OFF'}.")

def set_topic(room):
    t = input("Enter topic (blank to clear): ").strip()
    room["topic"] = t
    print(f"Topic set to: {room['topic']!r}")

def add_student(attendance, room):
    name = input("Student name to add: ").strip()
    if name:
        attendance.add(name)
        print(f"Added: {name}")
        if len(attendance) > room["capacity"]:
            print("ALERT: ROOM FULL")
    else:
        print("Name cannot be blank.")

def remove_student(attendance):
    name = input("Student name to remove: ").strip()
    if name in attendance:
        attendance.remove(name)
        print(f"Removed: {name}")
    else:
        print("Not in attendance.")

def add_temp(temps):
    try:
        x = float(input("Temperature (°C): ").strip())
        temps.append(x)
        if x < 16 or x > 28:
            print("WARNING: temperature out of range (16–28°C).")
    except ValueError:
        print("Enter a valid number.")

def stats(temps):
    if not temps:
        return None
    return (min(temps), max(temps), sum(temps)/len(temps))

def report(room, attendance, temps):
    print("\n=== ROOM REPORT ===")
    print(f"Projector: {'ON' if room['projector_on'] else 'OFF'}")
    print(f"Capacity: {len(attendance)}/{room['capacity']}")
    print(f"Topic: {room['topic'] or '(none)'}")
    s = stats(temps)
    if s is None:
        print("Temps: no readings")
    else:
        mn, mx, avg = s
        print(f"Temps: min={mn:.1f} max={mx:.1f} avg={avg:.1f}")
        last = temps[-1]
        if last < 16 or last > 28:
            print(f"WARNING: last reading {last:.1f}°C is out of range.")
    if len(attendance) > room["capacity"]:
        print("ALERT: ROOM FULL")

def main():
    room = {"projector_on": False, "capacity": 30, "topic": ""}
    attendance = set()
    temps = []

    while True:
        print("\n1) Toggle projector  2) Set topic  3) Add student  4) Remove student")
        print("5) Add temperature   6) Show stats 7) Report       8) Exit")
        choice = input("Choose: ").strip()
        if choice == "1": toggle_projector(room)
        elif choice == "2": set_topic(room)
        elif choice == "3": add_student(attendance, room)
        elif choice == "4": remove_student(attendance)
        elif choice == "5": add_temp(temps)
        elif choice == "6":
            s = stats(temps)
            print("No readings." if s is None else f"min={s[0]:.1f} max={s[1]:.1f} avg={s[2]:.1f}")
        elif choice == "7": report(room, attendance, temps)
        elif choice == "8":
            if room["topic"] and not room["projector_on"]:
                print("Reminder: projector is OFF while a topic is set.")
            print("Bye!")
            break
        else:
            print("Invalid option.")

if __name__ == "__main__":
    main()
