# Name: Md Tahmid Ul Islam Tonmoy | Student ID: u3310875 | Date: 16.09.2025

MENU = {
    "CF": ("Coffee", 4.50, "drink"),
    "TE": ("Tea", 3.80, "drink"),
    "MU": ("Muffin", 5.20, "food"),
    "SW": ("Sandwich", 8.90, "food"),
    "SA": ("Salad", 7.50, "food"),
    "JU": ("Juice", 4.00, "drink"),
}

def show_menu():
    print("\n=== MENU ===")
    print("Code  Item        Category  Price")
    for code, (name, price, cat) in MENU.items():
        print(f"{code:4s}  {name:10s}  {cat:8s}  ${price:.2f}")

def add_item(cart):
    code = input("Enter item code: ").strip().upper()
    qty_str = input("Enter quantity: ").strip()
    if not qty_str.isdigit():
        print("Quantity must be a positive integer."); return
    qty = int(qty_str)
    if code in MENU and qty > 0:
        name, price, cat = MENU[code]
        # merge if code exists
        for i, row in enumerate(cart):
            if row["code"] == code:
                cart[i]["qty"] += qty
                break
        else:
            cart.append({"code": code, "name": name, "cat": cat, "price": price, "qty": qty})
        print(f"Added {qty} x {name}.")
    else:
        print("Invalid code or quantity.")

def view_cart(cart):
    print("\n=== CART ===")
    if not cart:
        print("(empty)"); return
    subtotal = 0.0
    for row in cart:
        line_total = row["price"] * row["qty"]
        subtotal += line_total
        print(f"{row['qty']} x {row['name']} @ ${row['price']:.2f} = ${line_total:.2f}")
    print(f"Subtotal: ${subtotal:.2f}")

def checkout(cart):
    if not cart:
        print("Cart is empty."); return
    student = input("Student? (y/n): ").strip().lower() == "y"
    # totals
    subtotal = sum(r["price"] * r["qty"] for r in cart)
    has_food = any(r["cat"] == "food" for r in cart)
    has_drink = any(r["cat"] == "drink" for r in cart)
    meal_deal_disc = 1.00 if (has_food and has_drink) else 0.00
    after_meal = max(subtotal - meal_deal_disc, 0.0)
    student_disc = 0.05 * after_meal if student else 0.0
    after_discounts = after_meal - student_disc
    tax = 0.10 * after_discounts
    total = after_discounts + tax

    # receipt
    print("\n=== RECEIPT ===")
    for r in cart:
        line_total = r["price"] * r["qty"]
        print(f"{r['qty']} x {r['name']} @ ${r['price']:.2f} = ${line_total:.2f}")
    print(f"Subtotal:         ${subtotal:.2f}")
    if meal_deal_disc > 0:
        print(f"Meal-deal:       -${meal_deal_disc:.2f}")
    if student_disc > 0:
        print(f"Student 5%:      -${student_disc:.2f}")
    print(f"Tax 10%:          ${tax:.2f}")
    print(f"TOTAL:            ${total:.2f}\n")

    cart.clear()

def main():
    cart = []
    while True:
        print("\n1) Show menu  2) Add item  3) View cart  4) Checkout  5) Exit")
        choice = input("Choose: ").strip()
        if choice == "1":
            show_menu()
        elif choice == "2":
            add_item(cart)
        elif choice == "3":
            view_cart(cart)
        elif choice == "4":
            checkout(cart)
        elif choice == "5":
            print("Goodbye!"); break
        else:
            print("Invalid option.")

if __name__ == "__main__":
    main()
